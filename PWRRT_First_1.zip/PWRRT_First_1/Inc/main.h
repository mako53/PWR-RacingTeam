/*
 * main.h
 *
 *  Created on: Oct 27, 2024
 *      Author: Maks
 */

#ifndef MAIN_H_
#define MAIN_H_
#include <stdint.h>
#include <stm32f205xx.h>



#endif /* MAIN_H_ */
